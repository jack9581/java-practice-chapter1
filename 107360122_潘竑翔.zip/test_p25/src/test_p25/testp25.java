package test_p25;

public class testp25 
{

	public static void main(String[] args) 
	{
		int num;
		num=3;
		System.out.print("變數num的值是"+num);
	}
}
