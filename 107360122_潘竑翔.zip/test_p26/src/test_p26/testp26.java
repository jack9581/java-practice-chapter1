package test_p26;

public class testp26
{
	public static void main(String[] args)
	{
		int num=3;
		System.out.println("變數num的值是"+num);
		num=5;
		System.out.println("更新變數num的值");
		System.out.println("變數num更新號的值是"+num);
	}
}
