package test_p9;

public class test_p9
{

	public static void main(String[] args) 
	{
		System.out.print("歡迎使用Java!");
		System.out.print("開始使用Java吧!");
	}

}
