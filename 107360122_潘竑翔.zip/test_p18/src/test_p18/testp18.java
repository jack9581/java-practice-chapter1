package test_p18;

public class testp18 
{

	public static void main(String[] args) 
	{
		System.out.println("顯示出反斜線\\");
		System.out.println("顯示出單引號\'");
		System.out.println("八進位數101的字元是\101");
		System.out.println("十六進位數0061的字元是\u0061");
	}

}
