package test_p39;

public class test_p39 
{

	public static void main(String[] args) 
	{
		int d=2;
		double pi=3.14;
		System.out.println("直徑是"+d+"公分的圓");
		System.out.println("其圓周為"+(d*pi)+"公分");
		int num1=5,num2=4;
		double div1=num1/num2,div2=(double)num1/(double)num2;
		System.out.println("5/4等於"+div1);
		System.out.println("5/4等於"+div2);

	}

}
